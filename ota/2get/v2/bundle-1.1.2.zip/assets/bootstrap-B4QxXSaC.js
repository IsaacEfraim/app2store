const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/ota-updater-BxdARa7O.js","assets/preload-helper-Czpn1I53.js","assets/index-BCH9trGq.js","assets/rolldown-runtime-QTnfLwEv.js","assets/useStore-e-lcBoy7.js","assets/invariant-DEEwAagU.js","assets/link-BWqx-wIN.js","assets/createMiddleware-Criu1ETM.js","assets/qss-Bqk2G4CH.js","assets/redirect-Dhm19zUi.js","assets/root-DLTE-HSj.js","assets/client-P_XJZzdQ.js","assets/definitions-BXfyEA5k.js","assets/push-BYSBnNoK.js"])))=>i.map(i=>d[i]);
import{t as e}from"./preload-helper-Czpn1I53.js";import{j as t,k as n}from"./index-BCH9trGq.js";import{t as r}from"./esm-DU3lKYfC.js";var i;(function(e){e.Dark=`DARK`,e.Light=`LIGHT`,e.Default=`DEFAULT`})(i||={});var a;(function(e){e.None=`NONE`,e.Slide=`SLIDE`,e.Fade=`FADE`})(a||={});var o=t(`StatusBar`),s=!1,c=4e3;function l(){if(s)return;s=!0,n.getPlatform()===`android`&&e(async()=>{let{initOtaUpdater:e}=await import(`./ota-updater-BxdARa7O.js`);return{initOtaUpdater:e}},__vite__mapDeps([0,1,2,3,4,5,6,7,8,9,10,11,12])).then(({initOtaUpdater:e})=>e()),e(async()=>{let{supabase:e}=await import(`./client-P_XJZzdQ.js`).then(e=>e.t);return{supabase:e}},__vite__mapDeps([11,3,1])).then(({supabase:t})=>{t.auth.getSession().then(({data:t})=>{t.session&&e(()=>import(`./push-BYSBnNoK.js`).then(e=>e.initPushNotifications()),__vite__mapDeps([13,11,3,1,2,4,5,6,7,8,9,10]))}),t.auth.onAuthStateChange(t=>{t===`SIGNED_IN`&&window.setTimeout(()=>{e(()=>import(`./push-BYSBnNoK.js`).then(e=>e.initPushNotifications()),__vite__mapDeps([13,11,3,1,2,4,5,6,7,8,9,10]))},c),t===`SIGNED_OUT`&&e(()=>import(`./push-BYSBnNoK.js`).then(e=>e.unregisterPushToken()),__vite__mapDeps([13,11,3,1,2,4,5,6,7,8,9,10]))})}),r.addListener(`backButton`,({canGoBack:e})=>{!(window.location.pathname===`/`||window.location.pathname===``)&&(e||window.history.length>1)?window.history.back():r.minimizeApp()}),o.setStyle({style:i.Light}).catch(()=>{}),o.setBackgroundColor({color:`#ffffff`}).catch(()=>{});let t=document.createElement(`style`),a=`max(env(safe-area-inset-top), var(--safe-area-inset-top, 0px))`;t.textContent=`
    html {
      -webkit-tap-highlight-color: transparent;
      overscroll-behavior-y: none;
    }
    body {
      -webkit-user-select: none;
      user-select: none;
      -webkit-touch-callout: none;
      /* The viewport covers the whole screen so the tab bar can sit above the
         home indicator; keep page content clear of the status bar and the
         camera housing at the top. */
      padding-top: ${a};
      background-color: #ffffff;
    }
    /* Page headers stick to the top of the scroll port, which sits behind the
       status bar in a full screen web view — that is what pushed search fields
       and back buttons up under the clock and the battery icon. Stick them
       below the inset instead. */
    header.sticky.top-0 {
      top: ${a};
    }
    /* Padding only clears the status bar until the page scrolls: the content
       then travels up behind it, because the web view owns those pixels. Cap
       that area with an opaque strip so the clock and the signal, Wi-Fi and
       battery icons stay legible over whatever is scrolling underneath. */
    body::before {
      content: "";
      position: fixed;
      top: 0;
      left: 0;
      right: 0;
      height: ${a};
      background-color: #ffffff;
      pointer-events: none;
      z-index: 2147483000;
    }
    input, textarea, [contenteditable="true"] {
      -webkit-user-select: text;
      user-select: text;
    }
    /* Hide the web accessibility widget in the app — the OS provides
       system-level accessibility (font scaling, TalkBack/VoiceOver) */
    button[aria-label="פתיחת תפריט נגישות"] {
      display: none !important;
    }
  `,document.head.appendChild(t);let l=document.querySelector(`meta[name="viewport"]`);l&&l.setAttribute(`content`,`width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no, viewport-fit=cover`);let u=`/__l5e/`,d=e=>{if(e instanceof HTMLImageElement){let t=e.getAttribute(`src`);t?.startsWith(u)&&(e.src=`https://2get.work`+t)}};document.querySelectorAll(`img[src^="${u}"]`).forEach(d),new MutationObserver(e=>{for(let t of e)t.type===`attributes`&&t.target instanceof Element&&d(t.target),t.addedNodes.forEach(e=>{e instanceof Element&&(d(e),e.querySelectorAll?.(`img[src^="${u}"]`).forEach(d))})}).observe(document.documentElement,{subtree:!0,childList:!0,attributes:!0,attributeFilter:[`src`]})}export{l as initNativeShell};